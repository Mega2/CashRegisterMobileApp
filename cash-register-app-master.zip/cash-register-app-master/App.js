import React, { Component } from 'react';
import {
  AppRegistry,  
  Platform,
  StatusBar,
  StyleSheet,
  Text,
  ToolbarAndroid,
  View
} from 'react-native';
import { TabNavigator, StackNavigator } from 'react-navigation';
import Styles from './Styles';
import Keypad from './screens/Keypad';
import Cart from './screens/Cart';


// Tab Views
// const Menu = () => (
//   <View style={Styles.container}>
//     <StatusBar backgroundColor="#2196F3" barStyle="dark-content"/>
//   </View>
// );

// const Keypad = () => (
//   <View style={{flex: 1}}>
//     <View style={Styles.keypadDisplay}></View>
//     <View style={Styles.keypadInput}>
//       <View style={Styles.keypadInputRow}>
//         <View style={Styles.keypadInputButton}></View>
//         <View style={Styles.keypadInputButton}></View>
//         <View style={Styles.keypadInputButton}></View>
//       </View>
//       <View style={Styles.keypadInputRow}>
//         <View style={Styles.keypadInputButton}></View>
//         <View style={Styles.keypadInputButton}></View>
//         <View style={Styles.keypadInputButton}></View>
//       </View>
//       <View style={Styles.keypadInputRow}>
//         <View style={Styles.keypadInputButton}></View>
//         <View style={Styles.keypadInputButton}></View>
//         <View style={Styles.keypadInputButton}></View>
//       </View>
//       <View style={Styles.keypadInputRow}>
//         <View style={Styles.keypadInputButton}></View>
//         <View style={Styles.keypadInputButton}></View>
//         <View style={Styles.keypadInputButton}></View>
//       </View>
//     </View>
//   </View>
// );

// class Keypad extends Component {
//   render() {
//     return (
//       <View style={{flex: 1}}>
//         <View style={Styles.keypadDisplay}></View>
//         <View style={Styles.keypadInput}></View>
//       </View>
//     )
//   }
// }

// const Cart = () => (
//   <View style={Styles.container}>
//     <Text>Cart</Text>
//   </View>
// );

const App = StackNavigator({
  Keypad: {
    screen: Keypad,
    navigationOptions: () => ({
      header: null,
    }),
  },
  Cart: {
    screen: Cart,
    navigationOptions: () => ({
      header: null,
    }),
  } 
});

export default App;