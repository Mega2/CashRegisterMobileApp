# Cash Register
A lightweight app built with React Native meant to handle cash only transactions

Includes support for menu items and for custom transactions, ability to send receipts via text or email to customers, and ability to see total sales invoice per day.
